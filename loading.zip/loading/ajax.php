<?php
sleep(1);
echo 'Hola. Soy el nuevo contenido que viene del servidor!';
?>